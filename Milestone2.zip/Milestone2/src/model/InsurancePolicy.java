package model;
public class InsurancePolicy {
    private String policyNumber;
    private String insurerName;
    private String validity;

    public InsurancePolicy(String policyNumber, String insurerName, String validity) {
        this.policyNumber = policyNumber;
        this.insurerName = insurerName;
        this.validity = validity;
    }

    public String getPolicyNumber() { return policyNumber; }
    public String getInsurerName() { return insurerName; }
    public String getValidity() { return validity; }

    // Mock method to simulate policy retrieval
    public static InsurancePolicy retrievePolicy(String vin) {
        // Simulate retrieval - in real system, query database or API
        return new InsurancePolicy("POL12345", "Qatar Insurance", "2024-12-31");
    }
    @Override
    public String toString() {
        return "Insurance Policy Details\n" +
               "--------------------------------------\n" +
               "Policy Number: " + policyNumber + "\n" +
               "Insurer Name: " + insurerName + "\n" +
               "Validity: " + validity + "\n" +
               "--------------------------------------";
    }

}