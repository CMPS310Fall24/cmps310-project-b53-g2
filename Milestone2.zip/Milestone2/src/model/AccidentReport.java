package model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AccidentReport {

    private String vinOffending;
    private String vinVictim;
    private String location;
    private String description;
    private Date accidentDate;
    private String accidentTime;

    // Constructor
    public AccidentReport(String vinOffending, String vinVictim, String location, 
                          String description, Date accidentDate, String accidentTime) {
        this.vinOffending = vinOffending;
        this.vinVictim = vinVictim;
        this.location = location;
        this.description = description;
        this.accidentDate = accidentDate;
        this.accidentTime = accidentTime;
    }

    // Getters and Setters (if needed)
    public String getVinOffending() {
        return vinOffending;
    }

    public void setVinOffending(String vinOffending) {
        this.vinOffending = vinOffending;
    }

    public String getVinVictim() {
        return vinVictim;
    }

    public void setVinVictim(String vinVictim) {
        this.vinVictim = vinVictim;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getAccidentDate() {
        return accidentDate;
    }

    public void setAccidentDate(Date accidentDate) {
        this.accidentDate = accidentDate;
    }

    public String getAccidentTime() {
        return accidentTime;
    }

    public void setAccidentTime(String accidentTime) {
        this.accidentTime = accidentTime;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(accidentDate);

        return "Accident Report\n" +
               "--------------------------------------\n" +
               "Offending VIN: " + vinOffending + "\n" +
               "Victim VIN: " + vinVictim + "\n" +
               "Location: " + location + "\n" +
               "Accident Date: " + formattedDate + "\n" +
               "Accident Time: " + accidentTime + "\n" +
               "Description: " + description + "\n" +
               "--------------------------------------";
    }
}
