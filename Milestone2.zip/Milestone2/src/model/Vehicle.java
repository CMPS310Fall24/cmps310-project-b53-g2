package model;
public class Vehicle {
    private String vin;
    private String ownerName;
    private String registrationStatus;
    private boolean hasUnpaidBills;

    public Vehicle(String vin, String ownerName, String registrationStatus) {
        this.vin = vin;
        this.ownerName = ownerName;
        this.registrationStatus = registrationStatus;
    }
    public Vehicle(String vin, String ownerName, boolean hasUnpaidBills) {
        this.vin = vin;
        this.ownerName = ownerName;
        this.hasUnpaidBills = hasUnpaidBills;
    }
    public Vehicle(String vin, String ownerName) {
        this.vin = vin;
        this.ownerName = ownerName;
        this.hasUnpaidBills = false;  // Default to no unpaid bills
    }

    

    public String getVin() { return vin; }
    public String getOwnerName() { return ownerName; }
    public String getRegistrationStatus() { return registrationStatus; }
    

    public boolean isHasUnpaidBills() {
		return hasUnpaidBills;
	}
	public void setHasUnpaidBills(boolean hasUnpaidBills) {
		this.hasUnpaidBills = hasUnpaidBills;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}
	// Mock method to simulate vehicle retrieval
    public static Vehicle retrieveVehicle(String vin) {
        // Simulate retrieval - in real system, query database or API
        if (!vin.equals("000000")) {
            return new Vehicle(vin, "Owner Name", "Registered");
        }
        return null; // Null if VIN is invalid
    }
    
    
}
