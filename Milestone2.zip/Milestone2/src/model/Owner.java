package model;
public class Owner {
    private String name;
    private String qid;

    // Constructor
    public Owner(String name, String qid) {
        this.name = name;
        this.qid = qid;
    }

    // Getter for Name
    public String getName() {
        return name;
    }

    // Getter for QID
    public String getQid() {
        return qid;
    }
}