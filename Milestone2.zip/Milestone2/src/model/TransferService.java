package model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;


public class TransferService {
    private List<Vehicle> registeredVehicles;

    public TransferService() {
        registeredVehicles = new ArrayList<>();
        // Adding example vehicles to simulate a database
        registeredVehicles.add(new Vehicle("123ABC", "Haneen", false));  // No unpaid bills
        registeredVehicles.add(new Vehicle("156DEF", "Omar", true));     // Unpaid bills
        registeredVehicles.add(new Vehicle("789GHI", "Nahda", false));   // No unpaid bills
    }

    public static class TransferException extends Exception {
        public TransferException(String message) {
            super(message);
        }
    }

    // Verifies if the vehicle is registered and the owner matches
    public boolean verifyRegistration(Vehicle vehicle) throws TransferException {
        if (vehicle == null || vehicle.getVin().isEmpty()) {
            throw new TransferException("Invalid vehicle information.");
        }

        // Search for the vehicle by VIN
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vehicle.getVin())) {
                // Verify that the current owner matches
                if (!registeredVehicle.getOwnerName().equals(vehicle.getOwnerName())) {
                    throw new TransferException("Current owner does not match.");
                }
                return true;  // Vehicle found and valid
            }
        }
        throw new TransferException("Vehicle VIN is not registered.");
    }

    // Checks if the vehicle has unpaid bills and informs the user to pay them first
    public boolean checkForUnpaidBills(Vehicle vehicle) throws TransferException {
        if (vehicle.isHasUnpaidBills()) {
            throw new TransferException(getUnpaidBillsMessage(vehicle));
        }
        return true;  // No unpaid bills
    }

    // Transfers ownership from current owner to new owner
    public void transferOwnership(Vehicle vehicle, Owner newOwner) throws TransferException {
        if (newOwner == null || newOwner.getName().isEmpty() || newOwner.getQid().isEmpty()) {
            throw new TransferException("Invalid new owner information.");
        }

        // Update ownership in the system
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vehicle.getVin())) {
                registeredVehicle.setOwnerName(newOwner.getName());
                System.out.println("Ownership transferred to: " + newOwner.getName());
                break;
            }
        }
    }

    // Simulate generation of invoice for ownership transfer and save it to a file
    public void generateInvoice(Vehicle vehicle, Owner newOwner) {
        String invoiceDetails = "Ownership Transfer Invoice\n"
                + "Vehicle VIN: " + vehicle.getVin() + "\n"
                + "Previous Owner: " + vehicle.getOwnerName() + "\n"
                + "New Owner: " + newOwner.getName() + "\n"
                + "QID: " + newOwner.getQid() + "\n"
                + "Transfer Fee: 500 QAR\n"
                + "Date: " + java.time.LocalDate.now() + "\n";

        // Save invoice details to a file
        try {
            Files.write(Paths.get("invoice.txt"), invoiceDetails.getBytes(), StandardOpenOption.CREATE);
            System.out.println("Invoice saved to invoice.txt");

            // Read and display invoice content in the terminal
            String savedInvoice = new String(Files.readAllBytes(Paths.get("invoice.txt")));
            System.out.println("Invoice Contents:");
            System.out.println(savedInvoice); // Display the saved content

        } catch (IOException e) {
            System.err.println("Error saving invoice: " + e.getMessage());
        }
    }


    // Simulate preparation of new registration sticker and save it to a file
    public void prepareRegistrationSticker(Vehicle vehicle) {
        String stickerDetails = "Registration Sticker\n"
                + "Vehicle VIN: " + vehicle.getVin() + "\n"
                + "New Owner: " + vehicle.getOwnerName() + "\n"
                + "Expiration Date: 12/12/2025\n"; // Example expiration date

        // Save sticker details to a file
        try {
            Files.write(Paths.get("sticker.txt"), stickerDetails.getBytes(), StandardOpenOption.CREATE);
            System.out.println("Registration sticker saved to sticker.txt");

            // Read and display sticker content in the terminal
            String savedSticker = new String(Files.readAllBytes(Paths.get("sticker.txt")));
            System.out.println("Sticker Contents:");
            System.out.println(savedSticker); // Display the saved content

        } catch (IOException e) {
            System.err.println("Error saving registration sticker: " + e.getMessage());
        }
    }


    // Method to fetch vehicle details by VIN
    public Vehicle getVehicleDetails(String vin) throws TransferException {
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vin)) {
                return registeredVehicle;
            }
        }
        throw new TransferException("Vehicle with VIN " + vin + " not found.");
    }

    // Auto-complete VIN based on user input (return matching VINs by prefix)
    public List<String> getMatchingVins(String vinPrefix) {
        List<String> matchingVins = new ArrayList<>();
        for (Vehicle vehicle : registeredVehicles) {
            if (vehicle.getVin().startsWith(vinPrefix)) {
                matchingVins.add(vehicle.getVin());
            }
        }
        return matchingVins;
    }

    // Validate and prepare new owner details
    public void validateNewOwner(Owner newOwner) throws TransferException {
        if (newOwner == null || newOwner.getName().isEmpty() || newOwner.getQid().isEmpty()) {
            throw new TransferException("Invalid new owner details.");
        }

        // Check if the QID is already associated with another vehicle
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getOwnerName().equals(newOwner.getName())) {
                throw new TransferException("This QID is already associated with another vehicle. Cannot transfer ownership.");
            }
        }
    }

    // Method to get all registered vehicles (for UI purposes)
    public List<Vehicle> getAllRegisteredVehicles() {
        return registeredVehicles;
    }

    // Method to check if the vehicle has a valid registration status
    public boolean isVehicleRegistered(String vin) {
        for (Vehicle vehicle : registeredVehicles) {
            if (vehicle.getVin().equals(vin)) {
                return true;
            }
        }
        return false;
    }

    // Example of a service to check if the vehicle is eligible for ownership transfer (based on various criteria)
    public boolean isTransferEligible(Vehicle vehicle) throws TransferException {
        // Example check: Vehicle cannot be transferred if it is flagged as stolen or flagged for legal reasons
        boolean isFlagged = false; // Placeholder for flag status, this should be checked from some data source
        if (isFlagged) {
            throw new TransferException("This vehicle is flagged and cannot be transferred.");
        }
        return true;  // Vehicle is eligible for transfer
    }

    // Helper method to return a detailed unpaid bills message
    private String getUnpaidBillsMessage(Vehicle vehicle) {
        return "Vehicle owned by " + vehicle.getOwnerName() + " has unpaid bills. Please settle the dues before proceeding.";
    }
    
    public void saveToFile(String fileName, String content) throws IOException {
        try (FileWriter fileWriter = new FileWriter(fileName)) {
            fileWriter.write(content);
        }
    }
}