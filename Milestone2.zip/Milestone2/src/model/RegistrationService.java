package model;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import model.AccidentReport;
import model.InsurancePolicy;
import model.Vehicle;

public class RegistrationService {

    // Method to simulate retrieval of vehicle registration details
    public static Vehicle retrieveVehicleDetails(String vin) {
        // Mock data for the sake of example
        if (vin.equals("123456")) {
            return new Vehicle(vin, "Ahmed ", "Active");
        } else if (vin.equals("654321")) {
            return new Vehicle(vin, "Ali", "Active");
        }
        return null; // Return null if VIN is invalid
    }

    // Method to retrieve insurance policy details for a given VIN
    public static InsurancePolicy retrieveInsurancePolicy(String vin) {
        if (vin.equals("123456")) {
            return new InsurancePolicy("INS12345", "Qatar Insurance", "2025-01-01");
        } else if (vin.equals("654321")) {
            return new InsurancePolicy("INS67890", "Doha Insurance", "2025-06-30");
        }
        return null; // Return null if no insurance policy exists for VIN
    }

    // Method to validate VIN (for example, it checks a basic VIN format rule)
    public static boolean isValidVIN(String vin) {
        // For simplicity, assume valid VINs are exactly 6 characters long
        return vin != null && vin.length() == 6;
    }
    
    
    public static void submitAccidentReport(AccidentReport report) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("accident_reports.txt", true))) {
            writer.write(report.toString());  // Write the report to a file or database
            writer.newLine();
            System.out.println("Accident report submitted: " + report);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
