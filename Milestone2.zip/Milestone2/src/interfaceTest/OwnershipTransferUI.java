package interfaceTest;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import model.Owner;
import model.TransferService;
import model.Vehicle;

public class OwnershipTransferUI extends JFrame {

    private JPanel contentPane;
    private JTextField vinField, currentOwnerField, newOwnerField, qidField;
    private JList<String> vinSuggestionsList; // List to display VIN suggestions
    private TransferService transferService;
    private DefaultListModel<String> vinListModel; // Model for JList
    private JButton submitButton; // Submit button for ownership transfer
    private JLabel unpaidBillsLabel; // Label to show unpaid bills status

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                OwnershipTransferUI frame = new OwnershipTransferUI();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public OwnershipTransferUI() {
        setTitle("Transfer Registered Vehicle");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 500);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Instantiate TransferService
        transferService = new TransferService();

        // Adding fields and labels
        setupLabelsAndFields();

        // Submit button
        submitButton = new JButton("Submit Transfer");
        submitButton.setBounds(150, 350, 150, 30);
        contentPane.add(submitButton);

        // Add action listener to the submit button
        submitButton.addActionListener(e -> {
			try {
				handleTransferAction();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
    }

    // Sets up labels and input fields
    private void setupLabelsAndFields() {
        // VIN input
        JLabel vinLabel = new JLabel("VIN:");
        vinLabel.setBounds(30, 30, 200, 25);
        contentPane.add(vinLabel);

        vinField = new JTextField();
        vinField.setBounds(250, 30, 200, 25);
        contentPane.add(vinField);

        // Current Owner input
        JLabel currentOwnerLabel = new JLabel("Current Owner Name:");
        currentOwnerLabel.setBounds(30, 70, 200, 25);
        contentPane.add(currentOwnerLabel);

        currentOwnerField = new JTextField();
        currentOwnerField.setBounds(250, 70, 200, 25);
        currentOwnerField.setEditable(false); // Disable editing since we don't want the user to type it
        contentPane.add(currentOwnerField);

        // New Owner input
        JLabel newOwnerLabel = new JLabel("New Owner Name:");
        newOwnerLabel.setBounds(30, 110, 200, 25);
        contentPane.add(newOwnerLabel);

        newOwnerField = new JTextField();
        newOwnerField.setBounds(250, 110, 200, 25);
        contentPane.add(newOwnerField);

        // QID input
        JLabel qidLabel = new JLabel("New Owner QID:");
        qidLabel.setBounds(30, 150, 200, 25);
        contentPane.add(qidLabel);

        qidField = new JTextField();
        qidField.setBounds(250, 150, 200, 25);
        contentPane.add(qidField);

        // Create JList for VIN suggestions
        vinListModel = new DefaultListModel<>();
        vinSuggestionsList = new JList<>(vinListModel);
        vinSuggestionsList.setBounds(250, 60, 200, 100); // Adjust size and position
        vinSuggestionsList.setVisible(false); // Initially hide the list
        contentPane.add(vinSuggestionsList);

        // Add a listener to handle VIN input changes
        vinField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateVinSuggestions();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateVinSuggestions();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateVinSuggestions();
            }

            // Method to update the list of matching VINs
            private void updateVinSuggestions() {
                String vinPrefix = vinField.getText().trim();
                if (!vinPrefix.isEmpty()) {
                    List<String> matchingVins = transferService.getMatchingVins(vinPrefix);
                    vinListModel.clear();
                    for (String vin : matchingVins) {
                        vinListModel.addElement(vin);
                    }
                    vinSuggestionsList.setVisible(true); // Show the list
                } else {
                    vinListModel.clear();
                    vinSuggestionsList.setVisible(false); // Hide the list if input is empty
                }
            }
        });

        // Add a listener to handle selection of a VIN from the list
        vinSuggestionsList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedVin = vinSuggestionsList.getSelectedValue();
                if (selectedVin != null) {
                    vinField.setText(selectedVin);
                    populateOwnerName(selectedVin);
                    vinSuggestionsList.setVisible(false); // Hide the list after selection
                }
            }
        });

        // Unpaid Bills label
        unpaidBillsLabel = new JLabel("");
        unpaidBillsLabel.setBounds(30, 190, 400, 25);
        contentPane.add(unpaidBillsLabel);
    }

    // Populate the current owner field and unpaid bills status based on the VIN selected
    private void populateOwnerName(String vin) {
        try {
            Vehicle vehicle = transferService.getVehicleDetails(vin);
            currentOwnerField.setText(vehicle.getOwnerName());

            // Check for unpaid bills and show a warning if necessary
            if (vehicle.isHasUnpaidBills()) {
                unpaidBillsLabel.setText("Unpaid Bills: Yes");
                JOptionPane.showMessageDialog(this, "This vehicle has unpaid bills. Ownership transfer cannot proceed until bills are cleared.", 
                                              "Warning", JOptionPane.WARNING_MESSAGE);
                submitButton.setEnabled(false); // Disable the submit button
            } else {
                unpaidBillsLabel.setText("Unpaid Bills: No");
                submitButton.setEnabled(true); // Enable the submit button
            }

        } catch (TransferService.TransferException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Handles the action when the user clicks the "Submit Transfer" button
    private void handleTransferAction() throws IOException {
        try {
            // Validate and transfer ownership
            validateAndTransferOwnership();

            // Simulate saving the sticker and invoice to files
            String stickerFileName = "registration_sticker.txt";
            String invoiceFileName = "invoice.txt";
            
            // Save registration sticker and invoice to text files (you can customize this logic)
            transferService.saveToFile(stickerFileName, "Registration sticker generated for vehicle VIN: " + vinField.getText());
            try {
				transferService.saveToFile(invoiceFileName, "Invoice generated for new owner: " + newOwnerField.getText());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            // Show success message
            JOptionPane.showMessageDialog(this, "Ownership transfer successful!\nThe sticker and invoice have been generated and saved in files.", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (TransferService.TransferException ex) {
            // Show an error dialog with the message from the exception
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Validates the input and performs the ownership transfer
    private void validateAndTransferOwnership() throws TransferService.TransferException {
        String vin = vinField.getText();
        String currentOwnerName = currentOwnerField.getText();
        String newOwnerName = newOwnerField.getText();
        String qid = qidField.getText();

        // Validate inputs
        if (vin.isEmpty() || currentOwnerName.isEmpty() || newOwnerName.isEmpty() || qid.isEmpty()) {
            throw new TransferService.TransferException("Please fill in all fields.");
        }

        // Create objects for vehicle and new owner
        Vehicle vehicle = new Vehicle(vin, currentOwnerName);
        Owner newOwner = new Owner(newOwnerName, qid);

        // Validate registration and bills, perform transfer
        transferService.verifyRegistration(vehicle);
        transferService.checkForUnpaidBills(vehicle);
        transferService.transferOwnership(vehicle, newOwner);

        // Prepare registration sticker and generate invoice
        transferService.prepareRegistrationSticker(vehicle);  // Pass the vehicle object here
        transferService.generateInvoice(vehicle, newOwner);    // Pass both vehicle and new owner objects
    }

}