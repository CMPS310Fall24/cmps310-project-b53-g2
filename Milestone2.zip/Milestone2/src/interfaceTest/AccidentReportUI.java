package interfaceTest;
import model.RegistrationService;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import model.AccidentReport;
import model.Vehicle;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class AccidentReportUI extends JFrame {

    private JPanel contentPane;
    private JTextField vinOffendingField, vinVictimField, descriptionField;
    private JLabel statusLabel;
    private JButton retrieveDetailsButton, confirmButton, submitButton;
    private JLabel selectedDateLabel;
    private JPanel calendarPanel;
    private Calendar currentCalendar;
    private int selectedDay;
    private Vehicle offendingVehicle, victimVehicle;
    private AccidentReport report; // Store the report

    // Make these JComboBox variables instance variables
    private JComboBox<String> hourComboBox;
    private JComboBox<String> minuteComboBox;
    private JComboBox<String> locationComboBox; // Location ComboBox

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                AccidentReportUI frame = new AccidentReportUI();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public AccidentReportUI() {
        setTitle("Accident Report");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Offending vehicle VIN input
        JLabel vinOffendingLabel = new JLabel("Offending Vehicle VIN:");
        vinOffendingLabel.setBounds(30, 30, 200, 25);
        contentPane.add(vinOffendingLabel);

        vinOffendingField = new JTextField();
        vinOffendingField.setBounds(250, 30, 200, 25);
        contentPane.add(vinOffendingField);

        // Victim vehicle VIN input
        JLabel vinVictimLabel = new JLabel("Victim Vehicle VIN:");
        vinVictimLabel.setBounds(30, 70, 200, 25);
        contentPane.add(vinVictimLabel);

        vinVictimField = new JTextField();
        vinVictimField.setBounds(250, 70, 200, 25);
        contentPane.add(vinVictimField);

        // Accident Date input using custom calendar
        JLabel dateLabel = new JLabel("Accident Date:");
        dateLabel.setBounds(30, 110, 200, 25);
        contentPane.add(dateLabel);

        currentCalendar = Calendar.getInstance();
        calendarPanel = new JPanel(new GridLayout(0, 7));
        calendarPanel.setBounds(250, 110, 300, 200);
        contentPane.add(calendarPanel);
        calendarPanel.setEnabled(false); // Disable initially

        selectedDateLabel = new JLabel("Selected Date: ");
        selectedDateLabel.setBounds(250, 320, 300, 25);
        contentPane.add(selectedDateLabel);

        refreshCalendar();

        // Accident Time input (Hour and Minute)
        JLabel timeLabel = new JLabel("Accident Time:");
        timeLabel.setBounds(30, 360, 200, 25);
        contentPane.add(timeLabel);

        JLabel hourLabel = new JLabel("Hour:");
        hourLabel.setBounds(250, 360, 50, 25);
        contentPane.add(hourLabel);

        hourComboBox = new JComboBox<>();
        hourComboBox.setEditable(true);
        for (int i = 0; i < 24; i++) {
            hourComboBox.addItem(String.format("%02d", i));
        }
        hourComboBox.setBounds(300, 360, 60, 25);
        contentPane.add(hourComboBox);
        hourComboBox.setEnabled(false); // Disable initially

        JLabel minuteLabel = new JLabel("Minute:");
        minuteLabel.setBounds(370, 360, 50, 25);
        contentPane.add(minuteLabel);

        minuteComboBox = new JComboBox<>();
        minuteComboBox.setEditable(true);
        for (int i = 0; i < 60; i++) {
            minuteComboBox.addItem(String.format("%02d", i));
        }
        minuteComboBox.setBounds(420, 360, 60, 25);
        contentPane.add(minuteComboBox);
        minuteComboBox.setEnabled(false); // Disable initially

        // Accident Location using JComboBox
        JLabel locationLabel = new JLabel("Accident Location:");
        locationLabel.setBounds(30, 400, 200, 25);
        contentPane.add(locationLabel);

        // List of areas in Qatar
        String[] qatarAreas = {
            "Doha", "Al Rayyan", "Al Khor", "Al Wakrah", "Umm Salal", 
            "Al Daayen", "Al Shamal", "Mesaieed", "Dukhan", "Al Shahaniya", 
            "Lusail", "Madinat Khalifa", "Ain Khaled", "Al Gharrafa", "Al Sadd"
        };
        
        locationComboBox = new JComboBox<>(qatarAreas);
        locationComboBox.setBounds(250, 400, 200, 25);
        contentPane.add(locationComboBox);
        locationComboBox.setEnabled(false); // Disable initially

        // Description input
        JLabel descriptionLabel = new JLabel("Accident Description:");
        descriptionLabel.setBounds(30, 440, 200, 25);
        contentPane.add(descriptionLabel);

        descriptionField = new JTextField();
        descriptionField.setBounds(250, 440, 200, 25);
        contentPane.add(descriptionField);
        descriptionField.setEnabled(false); // Disable initially

        // Retrieve Details button
        retrieveDetailsButton = new JButton("Retrieve Vehicle Details");
        retrieveDetailsButton.setBounds(250, 480, 200, 30);
        contentPane.add(retrieveDetailsButton);

        // Confirm button
        confirmButton = new JButton("Confirm Accident Details");
        confirmButton.setBounds(250, 520, 200, 30);
        contentPane.add(confirmButton);
        confirmButton.setEnabled(false);

        // Submit button
        submitButton = new JButton("Submit Report");
        submitButton.setBounds(250, 560, 200, 30);
        contentPane.add(submitButton);
        submitButton.setEnabled(false);

        // Action listeners
        retrieveDetailsButton.addActionListener(e -> retrieveVehicleDetails());
        confirmButton.addActionListener(e -> confirmAccidentDetails());
        submitButton.addActionListener(e -> submitAccidentReport());
    }

    private void refreshCalendar() {
        calendarPanel.removeAll();
        String[] daysOfWeek = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String day : daysOfWeek) {
            JLabel dayLabel = new JLabel(day, SwingConstants.CENTER);
            calendarPanel.add(dayLabel);
        }

        currentCalendar.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = currentCalendar.get(Calendar.DAY_OF_WEEK) - 1;
        int daysInMonth = currentCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        for (int i = 0; i < firstDayOfWeek; i++) {
            calendarPanel.add(new JLabel(""));
        }

        for (int day = 1; day <= daysInMonth; day++) {
            int finalDay = day;
            JButton dayButton = new JButton(String.valueOf(day));
            dayButton.addActionListener(e -> selectDate(finalDay));
            calendarPanel.add(dayButton);
        }

        calendarPanel.revalidate();
        calendarPanel.repaint();
    }

    private void selectDate(int day) {
        selectedDay = day;
        int month = currentCalendar.get(Calendar.MONTH) + 1;
        int year = currentCalendar.get(Calendar.YEAR);
        selectedDateLabel.setText("Selected Date: " + day + "-" + month + "-" + year);
    }

    private void retrieveVehicleDetails() {
        String vinOffending = vinOffendingField.getText();
        String vinVictim = vinVictimField.getText();
        offendingVehicle = RegistrationService.retrieveVehicleDetails(vinOffending);
        victimVehicle = RegistrationService.retrieveVehicleDetails(vinVictim);

        if (offendingVehicle != null && victimVehicle != null) {
            // Enable the accident details fields after successful retrieval
            calendarPanel.setEnabled(true);
            locationComboBox.setEnabled(true);
            descriptionField.setEnabled(true);
            hourComboBox.setEnabled(true);
            minuteComboBox.setEnabled(true);

            confirmButton.setEnabled(true);
            JOptionPane.showMessageDialog(this, "Vehicle details retrieved successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid VINs or vehicles not found.");
        }
    }

    private void confirmAccidentDetails() {
        String location = (String) locationComboBox.getSelectedItem();
        String description = descriptionField.getText();
        int day = selectedDay;
        int month = currentCalendar.get(Calendar.MONTH);
        int year = currentCalendar.get(Calendar.YEAR);

        String hour = (String) hourComboBox.getSelectedItem();
        String minute = (String) minuteComboBox.getSelectedItem();
        String accidentTime = hour + ":" + minute;

        Calendar accidentCalendar = new GregorianCalendar(year, month, day, Integer.parseInt(hour), Integer.parseInt(minute));
        Date accidentDate = accidentCalendar.getTime();

        report = new AccidentReport(
            vinOffendingField.getText(),
            vinVictimField.getText(),
            location,
            description,
            accidentDate,
            accidentTime
        );
        submitButton.setEnabled(true);
        JOptionPane.showMessageDialog(this, "Accident details confirmed.");
    }

    private void submitAccidentReport() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("accident_reports.txt", true))) {
            writer.write(report.toString());
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Accident report submitted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

