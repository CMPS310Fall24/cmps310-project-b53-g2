package junitTest;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;

import org.junit.Test;

import model.AccidentReport;
import model.InsurancePolicy;
import model.RegistrationService;
import model.Vehicle;

public class RegistrationServiceTestCase {

	// Test for retrieveVehicleDetails method
    @Test
    public void testRetrieveVehicleDetails() {
        Vehicle vehicle1 = RegistrationService.retrieveVehicleDetails("123456");
        assertEquals("123456", vehicle1.getVin());
        assertEquals("Ahmed", vehicle1.getOwnerName().trim());  // Trim the owner name before comparison

        Vehicle vehicle2 = RegistrationService.retrieveVehicleDetails("654321");
        assertEquals("654321", vehicle2.getVin());
        assertEquals("Ali", vehicle2.getOwnerName().trim());  // Trim the owner name before comparison

        // Test invalid VIN
        Vehicle vehicleInvalid = RegistrationService.retrieveVehicleDetails("000000");
        assertEquals(null, vehicleInvalid);
    }

    // Test for retrieveInsurancePolicy method
    @Test
    public void testRetrieveInsurancePolicy() {
        InsurancePolicy policy1 = RegistrationService.retrieveInsurancePolicy("123456");
        assertEquals("INS12345", policy1.getPolicyNumber());
        assertEquals("Qatar Insurance", policy1.getInsurerName());
        assertEquals("2025-01-01", policy1.getValidity());

        InsurancePolicy policy2 = RegistrationService.retrieveInsurancePolicy("654321");
        assertEquals("INS67890", policy2.getPolicyNumber());
        assertEquals("Doha Insurance", policy2.getInsurerName());
        assertEquals("2025-06-30", policy2.getValidity());

        // Test invalid VIN
        InsurancePolicy policyInvalid = RegistrationService.retrieveInsurancePolicy("000000");
        assertEquals(null, policyInvalid);
    }

    // Test for isValidVIN method
    @Test
    public void testIsValidVIN() {
        assertEquals(true, RegistrationService.isValidVIN("123456"));  // Valid VIN
        assertEquals(true, RegistrationService.isValidVIN("654321"));  // Valid VIN
        assertEquals(false, RegistrationService.isValidVIN("12345"));  // Invalid VIN (too short)
        assertEquals(false, RegistrationService.isValidVIN("1234567")); // Invalid VIN (too long)
        assertEquals(false, RegistrationService.isValidVIN(null));      // Invalid VIN (null)
    }

    // Test for submitAccidentReport method
    @Test
    public void testSubmitAccidentReport() {
        AccidentReport report = new AccidentReport("VIN12345", "VIN54321", "Main Street", 
                                                   "Collision with minor damage", new Date(), "14:30");

        // Capture the output to verify the report submission
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        // Submit the report (will write to a file and print the message)
        RegistrationService.submitAccidentReport(report);

        // Check if the correct submission message is printed
        String expectedOutput = "Accident report submitted: AccidentReport{vinOffending='VIN12345', vinVictim='VIN54321', location='Main Street', description='Collision with minor damage', accidentDate=" + report.getAccidentDate() + ", accidentTime='14:30'}\n";
        assertEquals(true, outputStream.toString().contains("Accident report submitted:"));

        // Reset the System.out to default
        System.setOut(System.out);
    }

}
