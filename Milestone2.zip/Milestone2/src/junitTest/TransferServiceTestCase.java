package junitTest;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import model.TransferService;
import model.Vehicle;
import model.Owner;

import java.io.IOException;
import java.util.List;

public class TransferServiceTestCase {

    private TransferService transferService;
    private Vehicle vehicle;
    private Owner newOwner;

    @Before
    public void setUp() {
        transferService = new TransferService();
        vehicle = new Vehicle("123ABC", "Haneen", false);  // Example vehicle
        newOwner = new Owner("Ali", "56789");              // Example new owner
    }

    @Test
    public void testTransferService() {
        assertNotNull(transferService);
    }

    @Test
    public void testVerifyRegistration() {
        try {
            boolean isRegistered = transferService.verifyRegistration(vehicle);
            assertTrue(isRegistered);
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testCheckForUnpaidBills() {
        try {
            boolean noUnpaidBills = transferService.checkForUnpaidBills(vehicle);
            assertTrue(noUnpaidBills);
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testTransferOwnership() {
        try {
            transferService.transferOwnership(vehicle, newOwner);
            Vehicle updatedVehicle = transferService.getVehicleDetails("123ABC");
            assertEquals("Ali", updatedVehicle.getOwnerName());
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testGenerateInvoice() {
        transferService.generateInvoice(vehicle, newOwner);
        // Manually check the generated file or use file assertions
    }

    @Test
    public void testPrepareRegistrationSticker() {
        transferService.prepareRegistrationSticker(vehicle);
        // Manually check the generated file or use file assertions
    }

    @Test
    public void testGetVehicleDetails() {
        try {
            Vehicle result = transferService.getVehicleDetails("123ABC");
            assertNotNull(result);
            assertEquals("123ABC", result.getVin());
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testGetMatchingVins() {
        List<String> vins = transferService.getMatchingVins("123");
        assertEquals(1, vins.size());
        assertEquals("123ABC", vins.get(0));
    }

    @Test
    public void testValidateNewOwner() {
        try {
            transferService.validateNewOwner(newOwner);
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testGetAllRegisteredVehicles() {
        List<Vehicle> vehicles = transferService.getAllRegisteredVehicles();
        assertFalse(vehicles.isEmpty());
    }

    @Test
    public void testIsVehicleRegistered() {
        boolean isRegistered = transferService.isVehicleRegistered("123ABC");
        assertTrue(isRegistered);
    }

    @Test
    public void testIsTransferEligible() {
        try {
            boolean isEligible = transferService.isTransferEligible(vehicle);
            assertTrue(isEligible);
        } catch (TransferService.TransferException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    public void testSaveToFile() {
        try {
            transferService.saveToFile("testfile.txt", "Test content");
            // Manually check the generated file or use file assertions
        } catch (IOException e) {
            fail("IOException should not have been thrown");
        }
    }
}