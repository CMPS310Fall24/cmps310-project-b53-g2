package junitTest;

import static org.junit.Assert.*;

import org.junit.Test;

import model.Vehicle;

public class VehicleTestCase {

	// Test for constructor Vehicle(String vin, String ownerName, String registrationStatus)
    @Test
    public void testVehicleStringStringString() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", "Registered");
        assertEquals("123ABC", vehicle.getVin());
        assertEquals("Haneen", vehicle.getOwnerName());
        assertEquals("Registered", vehicle.getRegistrationStatus());
    }

    // Test for constructor Vehicle(String vin, String ownerName, boolean hasUnpaidBills)
    @Test
    public void testVehicleStringStringBoolean() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", false);
        assertEquals("123ABC", vehicle.getVin());
        assertEquals("Haneen", vehicle.getOwnerName());
        assertEquals(false, vehicle.isHasUnpaidBills());  // Using assertEquals for boolean

        // Test with unpaid bills
        Vehicle vehicleWithBills = new Vehicle("456DEF", "Omar", true);
        assertEquals(true, vehicleWithBills.isHasUnpaidBills());  // Using assertEquals for boolean
    }

    // Test for constructor Vehicle(String vin, String ownerName)
    @Test
    public void testVehicleStringString() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen");
        assertEquals("123ABC", vehicle.getVin());
        assertEquals("Haneen", vehicle.getOwnerName());
        assertEquals(false, vehicle.isHasUnpaidBills());  // Default to false
    }

    // Test for getVin() method
    @Test
    public void testGetVin() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", "Registered");
        assertEquals("123ABC", vehicle.getVin());
    }

    // Test for getOwnerName() method
    @Test
    public void testGetOwnerName() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", "Registered");
        assertEquals("Haneen", vehicle.getOwnerName());
    }

    // Test for getRegistrationStatus() method
    @Test
    public void testGetRegistrationStatus() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", "Registered");
        assertEquals("Registered", vehicle.getRegistrationStatus());
    }

    // Test for isHasUnpaidBills() method
    @Test
    public void testIsHasUnpaidBills() {
        Vehicle vehicle = new Vehicle("123ABC", "Haneen", false);
        assertEquals(false, vehicle.isHasUnpaidBills());  // Assert for no unpaid bills

        vehicle.setHasUnpaidBills(true);
        assertEquals(true, vehicle.isHasUnpaidBills());  // Assert for unpaid bills
    }

    // Test for retrieveVehicle method (static method)
    @Test
    public void testRetrieveVehicle() {
        Vehicle vehicle = Vehicle.retrieveVehicle("123ABC");
        assertEquals("123ABC", vehicle.getVin());
        assertEquals("Owner Name", vehicle.getOwnerName());
        assertEquals("Registered", vehicle.getRegistrationStatus());

        // Test for invalid VIN
        Vehicle invalidVehicle = Vehicle.retrieveVehicle("000000");
        assertEquals(null, invalidVehicle);
    }

}
