package junitTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.InsurancePolicy;

public class InsurancePolicyTestCase {

	private InsurancePolicy insurancePolicy = new InsurancePolicy("POL12345", "Qatar Insurance", "2024-12-31");

    // Test for the InsurancePolicy constructor
    @Test
    public void testInsurancePolicyConstructor() {
        testGetPolicyNumber();
        testGetInsurerName();
        testGetValidity();
    }

    // Test for the getPolicyNumber method
    @Test
    public void testGetPolicyNumber() {
        assertEquals("POL12345", insurancePolicy.getPolicyNumber());
    }

    // Test for the getInsurerName method
    @Test
    public void testGetInsurerName() {
        assertEquals("Qatar Insurance", insurancePolicy.getInsurerName());
    }

    // Test for the getValidity method
    @Test
    public void testGetValidity() {
        assertEquals("2024-12-31", insurancePolicy.getValidity());
    }

    // Test for the retrievePolicy method (mocking the policy retrieval)
    @Test
    public void testRetrievePolicy() {
        InsurancePolicy retrievedPolicy = InsurancePolicy.retrievePolicy("VIN12345");
        assertNotNull(retrievedPolicy);
        assertEquals("POL12345", retrievedPolicy.getPolicyNumber());
        assertEquals("Qatar Insurance", retrievedPolicy.getInsurerName());
        assertEquals("2024-12-31", retrievedPolicy.getValidity());
    }

    // Test for the toString method
    @Test
    public void testToString() {
        String expectedToString = "Insurance Policy Details\n" +
                                  "--------------------------------------\n" +
                                  "Policy Number: POL12345\n" +
                                  "Insurer Name: Qatar Insurance\n" +
                                  "Validity: 2024-12-31\n" +
                                  "--------------------------------------";
        assertEquals(expectedToString, insurancePolicy.toString());
    }

    

}
