package junitTest;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import java.util.Calendar;
import model.AccidentReport;
import java.text.SimpleDateFormat;

public class AccidentReportTestCase {

	 	private Date accidentDate = new Date(); // Use current date for the test
	    private AccidentReport accidentReport = new AccidentReport("VIN12345", "VIN54321", "Main Street", 
	                                                                 "Rear-end collision", accidentDate, "14:30");

	    // Test for the AccidentReport constructor
	    @Test
	    public void testAccidentReportConstructor() {
	        testGetVinOffending();
	        testGetVinVictim();
	        testGetLocation();
	        testGetDescription();
	        testGetAccidentDate();
	        testGetAccidentTime();
	    }

	    // Test for the getVinOffending method
	    @Test
	    public void testGetVinOffending() {
	        assertEquals("VIN12345", accidentReport.getVinOffending());
	    }

	    // Test for the getVinVictim method
	    @Test
	    public void testGetVinVictim() {
	        assertEquals("VIN54321", accidentReport.getVinVictim());
	    }

	    // Test for the getLocation method
	    @Test
	    public void testGetLocation() {
	        assertEquals("Main Street", accidentReport.getLocation());
	    }

	    // Test for the getDescription method
	    @Test
	    public void testGetDescription() {
	        assertEquals("Rear-end collision", accidentReport.getDescription());
	    }

	    // Test for the getAccidentDate method
	    @Test
	    public void testGetAccidentDate() {
	        assertEquals(accidentDate, accidentReport.getAccidentDate());
	    }

	    // Test for the getAccidentTime method
	    @Test
	    public void testGetAccidentTime() {
	        assertEquals("14:30", accidentReport.getAccidentTime());
	    }

    

    

    

}

