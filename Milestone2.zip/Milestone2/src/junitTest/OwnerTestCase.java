package junitTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.Owner;

public class OwnerTestCase {

	private Owner owner = new Owner("Haneen", "QID12345");

    // Test for the Owner constructor
    @Test
    public void testOwnerConstructor() {
        testGetName();
        testGetQid();
    }

    // Test for the getName method
    @Test
    public void testGetName() {
        assertEquals("Haneen", owner.getName());
    }

    // Test for the getQid method
    @Test
    public void testGetQid() {
        assertEquals("QID12345", owner.getQid());
    }

}
