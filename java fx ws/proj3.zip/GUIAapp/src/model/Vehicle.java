package model;



public class Vehicle {
    private String vin;
    private String currentOwner;
    private boolean hasUnpaidBills;

    // Constructor with unpaid bills info
    public Vehicle(String vin, String currentOwner, boolean hasUnpaidBills) {
        this.vin = vin;
        this.currentOwner = currentOwner;
        this.hasUnpaidBills = hasUnpaidBills;
    }

    // Constructor without unpaid bills info (default value to false)
    public Vehicle(String vin, String currentOwner) {
        this.vin = vin;
        this.currentOwner = currentOwner;
        this.hasUnpaidBills = false;  // Default to no unpaid bills
    }

    // Getters and setters
    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCurrentOwner() {
        return currentOwner;
    }

    public void setCurrentOwner(String currentOwner) {
        this.currentOwner = currentOwner;
    }

    public boolean hasUnpaidBills() {
        return hasUnpaidBills;
    }

    public void setUnpaidBills(boolean hasUnpaidBills) {
        this.hasUnpaidBills = hasUnpaidBills;
    }
}
