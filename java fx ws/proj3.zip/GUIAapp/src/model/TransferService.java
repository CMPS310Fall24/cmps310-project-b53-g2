package model;

import java.util.ArrayList;
import java.util.List;

public class TransferService {
    private List<Vehicle> registeredVehicles;

    public TransferService() {
        registeredVehicles = new ArrayList<>();
        // Adding example vehicles to simulate a database
        registeredVehicles.add(new Vehicle("123ABC", "John Doe", false));  // No unpaid bills
        registeredVehicles.add(new Vehicle("456DEF", "Alice Smith", true)); // Unpaid bills
        registeredVehicles.add(new Vehicle("789GHI", "Michael Johnson", false));
    }

    public static class TransferException extends Exception {
        public TransferException(String message) {
            super(message);
        }
    }

    // Verifies if the vehicle is registered and the owner matches
    public boolean verifyRegistration(Vehicle vehicle) throws TransferException {
        if (vehicle == null || vehicle.getVin().isEmpty()) {
            throw new TransferException("Invalid vehicle information.");
        }

        // Search for the vehicle by VIN
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vehicle.getVin())) {
                // Verify that the current owner matches
                if (!registeredVehicle.getCurrentOwner().equals(vehicle.getCurrentOwner())) {
                    throw new TransferException("Current owner does not match.");
                }
                return true;  // Vehicle found and valid
            }
        }
        throw new TransferException("Vehicle VIN is not registered.");
    }

    // Checks if the vehicle has unpaid bills
    public boolean checkForUnpaidBills(Vehicle vehicle) throws TransferException {
        if (vehicle.hasUnpaidBills()) {
            throw new TransferException("Vehicle has unpaid bills. Ownership cannot be transferred.");
        }
        return true;  // No unpaid bills
    }

    // Transfers ownership from current owner to new owner
    public void transferOwnership(Vehicle vehicle, Owner newOwner) throws TransferException {
        if (newOwner == null || newOwner.getName().isEmpty() || newOwner.getQid().isEmpty()) {
            throw new TransferException("Invalid new owner information.");
        }

        // Update ownership in the system
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vehicle.getVin())) {
                registeredVehicle.setCurrentOwner(newOwner.getName());
                System.out.println("Ownership transferred to: " + newOwner.getName());
                break;
            }
        }
    }

    // Simulate preparation of new registration sticker
    public void prepareRegistrationSticker() {
        System.out.println("New registration sticker prepared.");
    }

    // Simulate generation of invoice for ownership transfer
    public void generateInvoice() {
        System.out.println("Invoice generated for ownership transfer.");
    }

    // Method to fetch vehicle details by VIN
    public Vehicle getVehicleDetails(String vin) throws TransferException {
        for (Vehicle registeredVehicle : registeredVehicles) {
            if (registeredVehicle.getVin().equals(vin)) {
                return registeredVehicle;
            }
        }
        throw new TransferException("Vehicle with VIN " + vin + " not found.");
    }

    // Auto-complete VIN based on user input (return matching VINs by prefix)
    public List<String> getMatchingVins(String vinPrefix) {
        List<String> matchingVins = new ArrayList<>();
        for (Vehicle vehicle : registeredVehicles) {
            if (vehicle.getVin().startsWith(vinPrefix)) {
                matchingVins.add(vehicle.getVin());
            }
        }
        return matchingVins;
    }

    // Validate and prepare new owner details
    public void validateNewOwner(Owner newOwner) throws TransferException {
        if (newOwner == null || newOwner.getName().isEmpty() || newOwner.getQid().isEmpty()) {
            throw new TransferException("Invalid new owner details.");
        }
        // Additional validation can go here (e.g., check if the QID is already associated with another vehicle)
    }

    // Method to get all registered vehicles (for UI purposes)
    public List<Vehicle> getAllRegisteredVehicles() {
        return registeredVehicles;
    }

    // Method to check if the vehicle has a valid registration status
    public boolean isVehicleRegistered(String vin) {
        for (Vehicle vehicle : registeredVehicles) {
            if (vehicle.getVin().equals(vin)) {
                return true;
            }
        }
        return false;
    }

    // Example of a service to check if the vehicle is eligible for ownership transfer (based on various criteria)
    public boolean isTransferEligible(Vehicle vehicle) throws TransferException {
        // Example check: Vehicle cannot be transferred if it is flagged as stolen or flagged for legal reasons
        boolean isFlagged = false; // Placeholder for flag status, this should be checked from some data source
        if (isFlagged) {
            throw new TransferException("This vehicle is flagged and cannot be transferred.");
        }
        return true;  // Vehicle is eligible for transfer
    }
}
